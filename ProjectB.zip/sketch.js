let state = 0;
// Intro / Dialogue Variables
let introText = "1000 yrs later, the subject of the human hibernation \n project has yet to awaken......";
let displayText = "";
let index = 0;
let DT2 = "";
let id2 = 0;
let transitionImg;
let transitionProgress = 0;
let isTransitioning = false;
let nextState = null;

// Background Tile Scene
let bgImgs = [];
let bgTiles = [];
let bgCols = 2;
let bgRows = 2;
let bgImgWidth = 400;
let bgImgHeight = 300;
let showTitle = false;
let titleAlpha = 0;
let transitionStart = false;
let transitionProgress2 = 0;

// Kunqu Memory Scene
let kunquImgs = [];
let currentKunquIndex = 0;
let kunquPrevIndex = 0;
let audio;
let audioPlayed = false;
let veilGraphics;
let video;
let handPose;
let hands = [];
let seasonLabels = ["Spring", "Summer", "Autumn", "Winter"];
let currentAlpha = 255;
let nextAlpha = 0;
let fadeDuration = 2000; 
let isFading = false;
// ========== p5.js Functions ==========
function preload() {
  for (let i = 0; i < 4; i++) {
    bgImgs.push(loadImage('assets/' + i + '.jpg'));
    bgImgs[i].loadPixels();
  }
  for (let i = 4; i <= 6; i++) {
    kunquImgs.push(loadImage('assets/' + i + '.jpg'));
  }
  audio = loadSound('assets/kunqu.mp3');
  handPose = ml5.handPose();
}

function setup() {
  let canvas = createCanvas(800, 600);
  canvas.parent("p5-canvas-container");
  textFont("Georgia");
  textSize(24);
  fill(255);
  frameRate(30);

  veilGraphics = createGraphics(width, height);
  veilGraphics.background(0);
  veilGraphics.noStroke();

  video = createCapture(VIDEO);
  video.size(800, 600);
  video.hide();
  handPose.detectStart(video, gotHands);

  let bgIndex = 0;
  for (let y = 0; y < bgRows; y++) {
    for (let x = 0; x < bgCols; x++) {
      let tile = new BGTile(bgImgs[bgIndex], x * bgImgWidth, y * bgImgHeight, bgImgWidth, bgImgHeight, bgIndex);
      bgTiles.push(tile);
      bgIndex++;
    }
  }
}

function draw() {
  if (isTransitioning) {
    drawTransition();
    return;
  }

  if (state === 0) drawIntro();
  else if (state === 1) drawScientistDialogue();
  else if (state === 2) drawMindEntry();
  else if (state === 3) {for (let tile of bgTiles) {
    tile.update();
    tile.display();
  }
  rawBGScene();}
  else if (state === 4) drawKunquMemory();
}

// ========== State Scenes ==========
function drawIntro() {
  push();
  background(0);
  if (frameCount % 4 === 0 && index < introText.length) {
    displayText += introText.charAt(index);
    index++;
  }
  textAlign(CENTER, CENTER);
  text(displayText, width / 2, height / 2);
  if (index === introText.length) {
    fill(150);
    textSize(16);
    text("Press to continue", width / 2, height / 2 + 100);
  }
  pop();
}

function drawScientistDialogue() {
  push();
  background(10, 10, 30);
  fill(255);
  textAlign(LEFT, TOP);
  textSize(20);
  let dialogue = "The researcher：We couldn't wake him up... His consciousness is still stuck in his dreams... \n\nYou, you have to sneak into his subconsciousness and find a way to wake him up.";
  if (frameCount % 2 === 0 && id2 < dialogue.length) {
    DT2 += dialogue.charAt(id2);
    id2++;
  }
  text(DT2, 100, 100, 600, 300);
  if (id2 === dialogue.length) {
    fill(180);
    textSize(16);
    text("press any key to continue", 100, 500);
  }
  pop();
}

function drawMindEntry() {
  push();
  background(20, 0, 40);
  fill(255, 100, 200);
  textSize(28);
  textAlign(CENTER);
  text("You're entering his sub-consciousness……", width / 2, height / 2);
  noFill();
  stroke(255, 100);
  for (let i = 0; i < 20; i++) {
    ellipse(
      width / 2,
      height / 2,
      sin(frameCount * 0.05 + i) * 200,
      sin(frameCount * 0.05 + i) * 200
    );
  }

  fill(180);
  textSize(16);
  text("Press to continue", width / 2, height / 2 + 100);
  pop();
}

function drawBGScene() {
  
  if (showTitle) {
    fill(255, titleAlpha);
    textAlign(CENTER, CENTER);
    textSize(48);
    text("Dream of memories", width / 2, height / 2);
    if (titleAlpha < 255) titleAlpha += 2;
  }
  if (transitionStart) {
    transitionProgress2 += 0.01;
    fill(0, transitionProgress2 * 255);
    rect(0, 0, width, height);
    if (transitionProgress2 >= 1) {
      state = 4;
      if (!audioPlayed) {
        audio.play();
        audioPlayed = true;
      }
    }
  }
}

function drawKunquMemory() {
  let now = millis();
  if (isFading) {
    tint(255, currentAlpha);
    image(kunquImgs[kunquPrevIndex], 0, 0, width, height);

    tint(255, nextAlpha);
    image(kunquImgs[currentKunquIndex], 0, 0, width, height);
    noTint();

    let fadeStep = 255 / (fadeDuration / deltaTime);
    currentAlpha -= fadeStep;
    nextAlpha += fadeStep;
    currentAlpha = max(0, currentAlpha);
    nextAlpha = min(255, nextAlpha);

    if (currentAlpha <= 0 && nextAlpha >= 255) {
      isFading = false;
    }
  } else {
    image(kunquImgs[currentKunquIndex], 0, 0, width, height);
  }
  if (hands.length > 0) {
    for (let i = 0; i < hands.length; i++) {
      let hand = hands[i];
      for (let j = 0; j < hand.keypoints.length; j++) {
        let keypoint = hand.keypoints[j];
        let x = keypoint.x;
        let y = keypoint.y;
        veilGraphics.blendMode(REMOVE);
        veilGraphics.fill(0, 10);
        veilGraphics.ellipse(x, y, 100, 100);
        veilGraphics.blendMode(BLEND);
      }
    }
  }
  tint(255);
  image(veilGraphics, 0, 0, width, height);
  noTint();
}

// ========== Transition ========== //
function startTransition(toState) {
  transitionImg = get();
  transitionProgress = 0;
  nextState = toState;
  isTransitioning = true;
}

function drawTransition() {
  transitionProgress += 0.02;
  image(transitionImg, 0, 0);
  filter(BLUR, transitionProgress * 6);
  tint(255, 255 * (1 - transitionProgress));
  fill(255, 255 * transitionProgress);
  rect(0, 0, width, height);
  if (transitionProgress >= 1) {
    isTransitioning = false;
    state = nextState;
  }
}

// ========== Mouse & Key ========== //
function mousePressed() {
  if (state === 0 && index === introText.length) {
    startTransition(1);
  } else if (state === 2) {
    state = 3;
  } else if (state === 3) {
    for (let tile of bgTiles) {
      if (mouseX >= tile.x && mouseX <= tile.x + tile.w &&
          mouseY >= tile.y && mouseY <= tile.y + tile.h) {
        for (let t of bgTiles) {
          t.active = false;
          t.alpha = 0;
        }
        tile.active = true;
  
        if (tile.label === "Spring") {
          showTitle = true;
          setTimeout(() => {
            transitionStart = true;
          }, 3000); 
        }
      }
    }
  }
}

function keyPressed() {
  if (state === 1) {
    startTransition(2);
  }
}

function gotHands(results) {
  // Save the output to the hands variable
  hands = results;
}

// ========== BGTile Class ========== //
class BGTile {
  constructor(img, x, y, w, h, index) {
    this.img = img;
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.index = index;

    this.pg = createGraphics(w, h);
    this.img.loadPixels();

    this.active = false;
    this.alpha = 0;
    this.label = seasonLabels[index];
  }

  update() {
    let particleCount = this.active ? 600 : 150;
    let maxSize = this.active ? 4 : 15;

    for (let n = 0; n < particleCount; n++) {
      let px = floor(random(this.w));
      let py = floor(random(this.h));
      let imgX = floor(map(px, 0, this.w, 0, this.img.width));
      let imgY = floor(map(py, 0, this.h, 0, this.img.height));
      let i = (imgX + imgY * this.img.width) * 4;

      let r = this.img.pixels[i];
      let g = this.img.pixels[i + 1];
      let b = this.img.pixels[i + 2];

      this.pg.noStroke();
      this.pg.fill(r, g, b, this.active ? 255 : 150);
      this.pg.circle(px, py, random(1, maxSize));
    }

    if (this.active && this.alpha < 255) {
      this.alpha += 2;
    }
  }

  display() {
    image(this.pg, this.x, this.y);

    if (this.active) {
      push();
      textAlign(CENTER, CENTER);
      textStyle(ITALIC);
      textSize(64);
      fill(255, this.alpha);
      textFont('Times New Roman');
      text(this.label, this.x + this.w / 2, this.y + this.h / 2);
      pop();
    }
  }
}
